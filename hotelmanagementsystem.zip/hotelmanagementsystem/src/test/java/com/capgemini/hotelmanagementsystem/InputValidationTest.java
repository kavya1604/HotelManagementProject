package com.capgemini.hotelmanagementsystem;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagementsystem.factory.Factory;
import com.capgemini.hotelmanagementsystem.validations.InputValidation;

public class InputValidationTest {
	@Test
	@DisplayName("CustomerName")
	void testCustomerName() {
		InputValidation customerNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerNameValidation.nameValidation("kavya nalabolu"));
	}

	@Test
	@DisplayName("email")
	void testMailId() {
		InputValidation emailValidation = Factory.getInputValidationInstance();
		assertEquals(true, emailValidation.emailValidation("kavya16@gmail.com"));
	}

	@Test
	@DisplayName("contact number")
	void testPhno() {
		InputValidation phnoValidation = Factory.getInputValidationInstance();
		assertEquals(true, phnoValidation.hotelContactNumberValidation("9876543210"));
	}

	@Test
	@DisplayName("username")
	void testUserName() {
		InputValidation usernameValidation = Factory.getInputValidationInstance();
		assertEquals(true, usernameValidation.usernameValidation("kavya16"));
	}

	@Test
	@DisplayName("password")
	void testPassword() {
		InputValidation passwordValidation = Factory.getInputValidationInstance();
		assertEquals(true, passwordValidation.passwordValidation("Kavya@16"));
	}

	@Test
	@DisplayName("age")
	void testAge() {
		InputValidation ageValidation = Factory.getInputValidationInstance();
		assertEquals(true, ageValidation.ageValidation("23"));
	}

	@Test
	@DisplayName("coice")
	void testChoice() {
		InputValidation choiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, choiceValidation.choiceValidate("2"));
	}

	@Test
	@DisplayName("coiceAdmin")
	void testAdminChoice() {
		InputValidation adminchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, adminchoiceValidation.choiceValidateAdminOperation("3"));
	}

	@Test
	@DisplayName("specificHotelcoice")
	void testSpecificHotelChoice() {
		InputValidation specifichotelchoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, specifichotelchoiceValidation.choiceValidateBookingForSpecificHotel("2"));
	}

	@Test
	@DisplayName("booking date")
	void testBookingDate() {
		InputValidation bookingDateValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingDateValidation.bookingDateValidation("2020-05-04"));
	}

	@Test
	@DisplayName("hotel name")
	void testHotelName() {
		InputValidation hotelNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelNameValidation.hotelNameValidation("Taj Hotel"));
	}

	@Test
	@DisplayName("hotel adress")
	void testHotelAdress() {
		InputValidation hotelAdressValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelAdressValidation.hotelAddressValidation("Hyderabad"));
	}

	@Test
	@DisplayName("hotel contact number")
	void testHotelContactNumber() {
		InputValidation hotelContactNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelContactNumberValidation.hotelContactNumberValidation("9547860213"));
	}

	@Test
	@DisplayName("hotel details choice")
	void testHotelDetailsChoice() {
		InputValidation hotelDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, hotelDeatilsChoiceValidation.choiceValidateOperateHotelDetails("2"));
	}

	@Test
	@DisplayName("Room details choice")
	void testRoomDetailsChoice() {
		InputValidation roomDeatilsChoiceValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomDeatilsChoiceValidation.choiceValidateOperateRoomDetails("2"));
	}

	@Test
	@DisplayName("Customer Operations")
	void testCustomerOperations() {
		InputValidation customerOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, customerOperationsValidation.choiceValidateCustomerOperations("2"));
	}

	@Test
	@DisplayName("Employee Operations")
	void testEmployeeOperations() {
		InputValidation employeeOperationsValidation = Factory.getInputValidationInstance();
		assertEquals(true, employeeOperationsValidation.choiceValidateEmployeeOperations("2"));
	}

	@Test
	@DisplayName("room number")
	void testRoomNumber() {
		InputValidation roomNumberValidation = Factory.getInputValidationInstance();
		assertEquals(true, roomNumberValidation.roomNumberValidation("103"));
	}

	@Test
	@DisplayName("room type")
	void testRoomType() {
		InputValidation roomTypeValidation = Factory.getInputValidationInstance();
		assertEquals("single", roomTypeValidation.roomTypeValidation(1));
	}

	@Test
	@DisplayName("number of rooms")
	void testNumberOfRooms() {
		InputValidation noOfRoomsValidation = Factory.getInputValidationInstance();
		assertEquals(true, noOfRoomsValidation.numberOfRoomsValidation("26"));
	}

	@Test
	@DisplayName("booking name")
	void testBookingName() {
		InputValidation bookingNameValidation = Factory.getInputValidationInstance();
		assertEquals(true, bookingNameValidation.bookingNameValidation("kavya"));
	}

}
