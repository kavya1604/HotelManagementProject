package com.capgemini.hotelmanagementsystem;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelmanagementsystem.LoginTest;
import com.capgemini.hotelmanagementsystem.factory.Factory;
import com.capgemini.hotelmanagementsystem.service.Service;

public class LoginTest {
	static final Logger log = Logger.getLogger(LoginTest.class);
	Scanner scanner = new Scanner(System.in);

	@Test
	@DisplayName("Admin Login")
	void testadminLoginTest() throws IOException {

		log.info("Test Case for Admin Login");
		Service adminLogin = Factory.getServiceInstance();
		assertEquals(true, adminLogin.getAdminLogin("admin", "Admin@123"));
	}

	@Test
	@DisplayName("Admin Login")
	void testadminLoginTest1() throws IOException {

		log.info("Test Case for Admin Login");
		Service adminLogin = Factory.getServiceInstance();
		assertEquals(false, adminLogin.getAdminLogin("admin12", "Admin@1234"));
	}

	@Test
	@DisplayName("Employee Login")
	void testemployeeLoginTest() {
		log.info("Test Case for employee Login");
		Service employeeLogin = Factory.getServiceInstance();
		assertEquals(true, employeeLogin.getHotelManagementLogin("saikumar12", "Saikumar@12"));
	}

	@Test
	@DisplayName("Employee Login")
	void testemployeeLoginTest1() {
		log.info("Test Case for employee Login");
		Service employeeLogin = Factory.getServiceInstance();
		assertEquals(false, employeeLogin.getHotelManagementLogin("saikumar", "Saikumar@1203"));

	}

	@Test
	@DisplayName("Customer Login")
	void testcustomerLoginTest() {

		log.info("Test Case for Customer Login");
		Service customerLogin = Factory.getServiceInstance();
		assertEquals(true, customerLogin.getLoginCustomer("kavya16", "Kavya@16"));

	}

	@Test
	@DisplayName("Customer Login")
	void testcustomerLoginTest2() {

		log.info("Test Case for Customer Login");
		Service customerLogin = Factory.getServiceInstance();
		assertEquals(false, customerLogin.getLoginCustomer("kavya", "Kavya@1622"));

	}

}
