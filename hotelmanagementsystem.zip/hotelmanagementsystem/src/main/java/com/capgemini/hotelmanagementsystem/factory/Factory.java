package com.capgemini.hotelmanagementsystem.factory;

import com.capgemini.hotelmanagementsystem.bean.HotelManagementLogin;
import com.capgemini.hotelmanagementsystem.bean.Room;
import com.capgemini.hotelmanagementsystem.controller.AdminController;
import com.capgemini.hotelmanagementsystem.controller.CustomerController;
import com.capgemini.hotelmanagementsystem.controller.HotelManagementController;
import com.capgemini.hotelmanagementsystem.bean.Booking;
import com.capgemini.hotelmanagementsystem.bean.AdminLogin;
import com.capgemini.hotelmanagementsystem.bean.CustomerRegistration;
import com.capgemini.hotelmanagementsystem.bean.Hotel;
import com.capgemini.hotelmanagementsystem.dao.Dao;
import com.capgemini.hotelmanagementsystem.dao.DaoImpl;
import com.capgemini.hotelmanagementsystem.service.Service;
import com.capgemini.hotelmanagementsystem.service.ServiceImpl;
import com.capgemini.hotelmanagementsystem.validations.InputValidation;
import com.capgemini.hotelmanagementsystem.validations.InputValidationImpl;

/**
 * In this class we will create objects for all classes
 *
 */
public class Factory {
	private Factory() {

	}

	public static InputValidation getInputValidationInstance() {

		return new InputValidationImpl();
	}

	public static Service getServiceInstance() {
		Service service = new ServiceImpl();
		return service;

	}

	public static CustomerRegistration getCustomerRegistrationInstance() {
		CustomerRegistration customerRegistration = new CustomerRegistration();
		return customerRegistration;
	}

	public static Dao getDaoInstance() {
		Dao dao = new DaoImpl();
		return dao;
	}

	public static AdminLogin getAdminInstance() {
		return new AdminLogin();
	}

	public static HotelManagementLogin getHotelManagementLoginInstance() {
		return new HotelManagementLogin();
	}

	public static Booking getBookingInstance() {
		return new Booking();
	}

	public static Hotel getHotelInstance() {
		return new Hotel();
	}

	public static Room getRoomInstance() {
		return new Room();
	}

	public static AdminController getAdminControllerInstance() {
		return new AdminController();
	}

	public static CustomerController getCustomerControllerInstance() {
		return new CustomerController();
	}

	public static HotelManagementController getHotelManagementControllerInstance() {
		return new HotelManagementController();
	}
}
