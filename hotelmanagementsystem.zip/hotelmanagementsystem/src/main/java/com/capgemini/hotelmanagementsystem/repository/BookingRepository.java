package com.capgemini.hotelmanagementsystem.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementsystem.bean.Booking;
import com.capgemini.hotelmanagementsystem.factory.Factory;

public class BookingRepository {
	public static List<Booking> bookList = new ArrayList<Booking>();

	public List<Booking> getBookingRepository() {

		Booking booking = Factory.getBookingInstance();

		booking.setFromDate(LocalDate.of(2020, 04, 23));
		booking.setToDate(LocalDate.of(2020, 04, 24));
		booking.setName("kavya");
		booking.setHotelName("Tajhotel");
		booking.setAddress("hyderabad");
		booking.setEmail("kavya16@gmail.com");
		booking.setContactNumber(9876543210l);
		booking.setRoomNum(102);

		Booking booking2 = Factory.getBookingInstance();

		booking2.setFromDate(LocalDate.of(2020, 04, 25));
		booking2.setToDate(LocalDate.of(2020, 04, 26));
		booking2.setName("keerthi");
		booking2.setHotelName("AthithiGrandhotel");
		booking2.setAddress("vijayawada");
		booking2.setEmail("keerthi27@gmail.com");
		booking2.setContactNumber(8456792137l);
		booking2.setRoomNum(101);

		Booking booking3 = Factory.getBookingInstance();

		booking3.setFromDate(LocalDate.of(2020, 04, 26));
		booking3.setToDate(LocalDate.of(2020, 04, 27));
		booking3.setName("sahithi");
		booking3.setHotelName("Tajhotel");
		booking3.setAddress("Banglore");
		booking3.setEmail("sahithi14@gmail.com");
		booking3.setContactNumber(8794561230l);
		booking3.setRoomNum(103);

		bookList.add(booking);
		bookList.add(booking2);
		bookList.add(booking3);
		return bookList;
	}

	public boolean setBookingMethod(Booking b) {

		bookList.add(b);

		return false;
	}

}
