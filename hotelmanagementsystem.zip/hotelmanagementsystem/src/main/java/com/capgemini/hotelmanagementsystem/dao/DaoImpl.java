package com.capgemini.hotelmanagementsystem.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import com.capgemini.hotelmanagementsystem.bean.AdminLogin;
import com.capgemini.hotelmanagementsystem.bean.Booking;
import com.capgemini.hotelmanagementsystem.bean.CustomerRegistration;
import com.capgemini.hotelmanagementsystem.bean.Hotel;
import com.capgemini.hotelmanagementsystem.bean.HotelManagementLogin;
import com.capgemini.hotelmanagementsystem.bean.Room;
import com.capgemini.hotelmanagementsystem.repository.BookingRepository;
import com.capgemini.hotelmanagementsystem.repository.CustomerRegistrationRepository;
import com.capgemini.hotelmanagementsystem.repository.HotelManagementRepository;
import com.capgemini.hotelmanagementsystem.repository.HotelRepository;
import com.capgemini.hotelmanagementsystem.repository.RoomRepository;

/**
 * Implementation class for Dao Interface
 * 
 */
public class DaoImpl implements Dao {

	private static Properties property = null;

	static List<AdminLogin> adminlist = new ArrayList<AdminLogin>();

	static List<CustomerRegistration> customerlist = new CustomerRegistrationRepository()
			.getCustomerRegistrationRepository();
	static List<HotelManagementLogin> managementList = new HotelManagementRepository().getHotelManagementRepository();
	static List<Hotel> hotelList = new HotelRepository().getHotelRepository();
	static List<Booking> bookList = new BookingRepository().getBookingRepository();
	static List<Room> roomList = new RoomRepository().getRoomRepository();
	int CustomerlistSize = customerlist.size();
	int HotellistSize = hotelList.size();
	int BooklistSize = bookList.size();
	int RoomlistSize = roomList.size();

	public boolean addCustomer(CustomerRegistration customerRegistration) {
		customerlist.add(customerRegistration);
		return CustomerlistSize != customerlist.size() + 1;
	}

	public boolean getLoginRequest(String username, String password) {
		int count = 0;
		Iterator<CustomerRegistration> itr = customerlist.iterator();

		while (itr.hasNext()) {

			CustomerRegistration customer1 = itr.next();

			if (username.equals(customer1.getUserName()) && password.equals(customer1.getPassword()))
				count++;

		}
		return count != 0;
	}

	public boolean getAdminLoginRequest(String userName, String password) throws IOException {
		int count = 0;
		property = new Properties();
		FileInputStream fileInputStream = new FileInputStream("db.properties");
		property.load(fileInputStream);
		String userName1 = property.getProperty("adminUserName");
		String password1 = property.getProperty("adminPassword");

		if (userName.equals(userName1) && password.equals(password1))
			count++;

		return count == 0 ? false : true;
	}

	public boolean getHotelManagementLoginRequest(String username, String password) {
		int count = 0;
		for (HotelManagementLogin managementLogin : managementList) {

			if (managementLogin.getUserName().equals(username) && managementLogin.getPassword().equals(password))
				count++;
		}
		return count != 0;
	}

	public List<Hotel> getAllHotels(Hotel hotel) {
		return hotelList;

	}

	public List<Booking> getAllBookingsList(Booking booking) {
		return bookList;
	}

	public boolean getBookingForHotel(String hotelName) {
		int count = 0;
		for (Booking booking1 : bookList) {
			if (booking1.getHotelName().equals(hotelName)) {
				count++;
			}
		}
		return count != 0;

	}

	public boolean addBooking(Booking booking) {
		bookList.add(booking);
		return BooklistSize != bookList.size() + 1;

	}

	public List<CustomerRegistration> getAllCustomers(CustomerRegistration customerRegistration) {
		return customerlist;
	}

	public boolean addHotel(Hotel hotel) {
		hotelList.add(hotel);
		return HotellistSize != hotelList.size() + 1;
	}

	public boolean deleteHotel(String hotelName) {
		int count = 0;
		Iterator<Hotel> hotel = hotelList.iterator();
		while (hotel.hasNext()) {
			Hotel str = hotel.next();
			if (str.getHotelName().equals(hotelName)) {
				hotel.remove();
				count++;
			}
		}

		return count == 0 ? false : true;
	}

	public boolean updateHotel(String hotelName) {

		for (Hotel hotel : hotelList) {
			if (hotel.getHotelName().equals(hotelName)) {

				return true;
			}
		}

		return false;

	}

	public Hotel getHotel(String hotelName) {
		for (Hotel hotel2 : hotelList) {
			if (hotel2.getHotelName().equals(hotelName)) {
				return hotel2;
			}
		}
		return null;
	}

	public boolean addRoom(Room room) {
		roomList.add(room);
		return RoomlistSize != roomList.size() + 1;
	}

	public boolean deleteRoom(String roomNumber) {
		int count = 0;
		Iterator<Room> room = roomList.iterator();
		while (room.hasNext()) {
			Room str = room.next();
			int roomNumber1 = Integer.parseInt(roomNumber);
			if (str.getRoomNumber() == (roomNumber1)) {
				room.remove();
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	public List<Booking> getBookingListRequest() {
		return bookList;
	}

	public boolean updateRoom(int roomNumber) {
		for (Room roomdetails : roomList) {
			if (roomdetails.getRoomNumber() == (roomNumber)) {
				return true;
			}
		}
		return false;
	}

	public boolean updateHotelDetails(String hotelName1, Hotel hotel) {
		int count = 0;
		for (Hotel hotel1 : hotelList) {
			if (hotel1.getHotelName().contentEquals(hotelName1)) {
				hotel1.setHotelName(hotel.getHotelName());
				hotel1.setContactNumber(hotel.getContactNumber());
				hotel1.setHotelAddress(hotel.getHotelAddress());
				hotel1.setNoOfRooms(hotel.getNoOfRooms());
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	public boolean updateRoomDetails(int roomNumber, Room room) {
		int count = 0;
		for (Room room1 : roomList) {
			if (room1.getRoomNumber() == roomNumber) {
				room1.setRoomNumber(room.getRoomNumber());
				room1.setRoomPrice(room.getRoomPrice());
				room1.setRoomType(room.getRoomType());
				count++;
			}
		}
		return count == 0 ? false : true;
	}

	public List<Hotel> getHotelList() {

		return hotelList;
	}
}
