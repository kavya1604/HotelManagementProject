package com.capgemini.hotelmanagementsystem.exception;

public class RoomNumberNotFoundException extends Exception {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public RoomNumberNotFoundException() {

	}
}
