package com.capgemini.hotelmanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementsystem.bean.CustomerRegistration;
import com.capgemini.hotelmanagementsystem.factory.Factory;

public class CustomerRegistrationRepository {
	List<CustomerRegistration> customer = new ArrayList<CustomerRegistration>();

	@SuppressWarnings("unused")
	public List<CustomerRegistration> getCustomerRegistrationRepository() {
		CustomerRegistration customer1 = Factory.getCustomerRegistrationInstance();
		customer1.setName("kavya nalabolu");
		customer1.setUserName("kavya16");
		customer1.setPassword("Kavya@16");
		customer1.setPhno(9876543210l);
		customer1.setMailId("kavya16@gmail.com");
		customer1.setAge(23);

		CustomerRegistration customer2 = Factory.getCustomerRegistrationInstance();
		customer2.setName("keerthi reddy");
		customer2.setUserName("keerthi27");
		customer2.setPassword("keerthi@27");
		customer2.setPhno(7965556545l);
		customer2.setMailId("keerthi27@gmail.com");
		customer2.setAge(26);

		CustomerRegistration customer3 = Factory.getCustomerRegistrationInstance();
		customer3.setName("sahithi reddy");
		customer3.setUserName("sahithi14");
		customer3.setPassword("sahithi@14");
		customer3.setPhno(9856425457l);
		customer3.setMailId("sahithi14@gmail.com");
		customer3.setAge(24);

		customer.add(customer1);
		customer.add(customer2);
		customer.add(customer3);
		int size = customer.size();

		return customer;

	}

	public boolean setCustomerMethod(CustomerRegistration cr) {

		customer.add(cr);

		return false;

	}
}
