package com.capgemini.hotelmanagementsystem.repository;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hotelmanagementsystem.factory.Factory;
import com.capgemini.hotelmanagementsystem.bean.HotelManagementLogin;

public class HotelManagementRepository {
	List<HotelManagementLogin> managementList = new ArrayList<HotelManagementLogin>();

	public List<HotelManagementLogin> getHotelManagementRepository() {
		HotelManagementLogin hotelManagementLogin = Factory.getHotelManagementLoginInstance();
		hotelManagementLogin.setUserName("saikumar12");
		hotelManagementLogin.setPassword("Saikumar@12");
		managementList.add(hotelManagementLogin);
		HotelManagementLogin hotelManagementLogin1 = Factory.getHotelManagementLoginInstance();
		hotelManagementLogin1.setUserName("manikanta20");
		hotelManagementLogin1.setPassword("manikanta@20");
		managementList.add(hotelManagementLogin1);
		return managementList;
	}

	public boolean setEmployeeMethod(HotelManagementLogin h) {

		managementList.add(h);

		return false;

	}

}
