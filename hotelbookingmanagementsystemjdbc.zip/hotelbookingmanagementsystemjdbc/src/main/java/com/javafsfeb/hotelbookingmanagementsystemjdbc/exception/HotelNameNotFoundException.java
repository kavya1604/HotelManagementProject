package com.javafsfeb.hotelbookingmanagementsystemjdbc.exception;

public class HotelNameNotFoundException extends Exception {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public HotelNameNotFoundException() {

	}
}
