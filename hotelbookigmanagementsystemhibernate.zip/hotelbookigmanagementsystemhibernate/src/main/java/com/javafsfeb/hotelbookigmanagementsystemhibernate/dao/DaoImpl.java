package com.javafsfeb.hotelbookigmanagementsystemhibernate.dao;

import java.io.IOException;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.AdminLogin;
import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.Booking;
import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.CustomerRegistration;
import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.Hotel;
import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.HotelManagementLogin;
import com.javafsfeb.hotelbookigmanagementsystemhibernate.bean.Room;




/**
 * Implementation class for Dao Interface
 * 
 */
public class DaoImpl implements Dao {
	private static EntityManagerFactory factory = 
			Persistence.createEntityManagerFactory("hibernatedb");
	public boolean addCustomer(CustomerRegistration customerRegistration) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			//factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();	
			manager.persist(customerRegistration);
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		} finally {
		manager.close();
	//	factory.close();
		}
	//	return false;

			
				}

	public boolean getLoginRequest(String username, String password) {
		EntityManager manager = null;
		try {
			factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			
			String jpql = "select m from CustomerRegistration m where m.userName = :userName and m.password =:password  ";
					TypedQuery<CustomerRegistration>  query = manager.createQuery(jpql, CustomerRegistration.class);
			query.setParameter("userName",username);
			query.setParameter("password", password);
		
			CustomerRegistration info = (CustomerRegistration) query.getSingleResult();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
			//factory.close();
		}
		return false;
				}

	public boolean getAdminLoginRequest(String username, String password) throws IOException {
		EntityManager manager = null;
		try {
			factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			
			String jpql = "select m from AdminLogin m where m.userName = :userName and m.password =:password  ";
					TypedQuery<AdminLogin>  query = manager.createQuery(jpql,AdminLogin.class);
			query.setParameter("userName",username);
			query.setParameter("password", password);
		
			AdminLogin info = (AdminLogin) query.getSingleResult();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
			//factory.close();
		}
		return false;	}

	public boolean getHotelManagementLoginRequest(String username, String password) {
		EntityManager manager = null;
		try {
			factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			
			String jpql = "select m from HotelManagementLogin m where m.userName = :userName and m.password =:password  ";
					TypedQuery<HotelManagementLogin>  query = manager.createQuery(jpql, HotelManagementLogin.class);
			query.setParameter("userName",username);
			query.setParameter("password", password);
			HotelManagementLogin info = (HotelManagementLogin) query.getSingleResult();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			manager.close();
			//factory.close();
		}
		return false;
	}

	public List<Hotel> getAllHotels(Hotel hotel) {
		EntityManagerFactory factory =null;
		EntityManager manager = null;
//		try (FileInputStream fileInputStream = new FileInputStream("databaseproperties.properties")) {
//			Properties properties = new Properties();
//			properties.load(fileInputStream);
	//	factory = Persistence.createEntityManagerFactory("hibernatedb");
		try {
		manager = factory.createEntityManager();
		String jpql = "select m from Hotel m";
		TypedQuery<Hotel> query = manager.createQuery(jpql,Hotel.class);
		List<Hotel> recordlist = query.getResultList();
		return recordlist;
	} catch(Exception e) {
		e.getMessage();
	} finally {
		manager.close();
	//	factory.close();
	}
		return null;	
	}

	public List<Booking> getAllBookingsList() {
		EntityManagerFactory factory =null;
		EntityManager manager = null;

		try {
		manager = factory.createEntityManager();
		String jpql = "select m from Booking m";
		TypedQuery<Booking> query = manager.createQuery(jpql, Booking.class);
		List<Booking> recordlist = query.getResultList();
		return recordlist;
	} catch(Exception e) {
		e.getMessage();
	} 
		manager.close();
		return null;
		}

		

	public boolean getBookingForHotel(String hotelName) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean addBooking(Booking booking) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			//factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();	
			manager.persist(booking);
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		} finally {
		manager.close();
	//	factory.close();
		}	}

	public List<CustomerRegistration> getAllCustomers(CustomerRegistration customerRegistration) {
		EntityManagerFactory factory =null;
		EntityManager manager = null;
		try {
		manager = factory.createEntityManager();
		String jpql = "select m from CustomerRegistration m";
		TypedQuery<CustomerRegistration> query = manager.createQuery(jpql, CustomerRegistration.class);
		List<CustomerRegistration> recordlist = query.getResultList();
		return recordlist;
	} catch(Exception e) {
		e.getMessage();
	} finally {
		manager.close();
	//	factory.close();
	}
		return null;	
		}

	public boolean addHotel(Hotel hotel) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();	
			manager.persist(hotel);
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		} finally {
		manager.close();
	
		}
	
	}
	
	public boolean deleteHotel(String hotelName) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
	
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			Hotel removeHotel=manager.find(Hotel.class, hotelName);
			manager.remove(removeHotel);
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
		manager.close();
	//	factory.close();
		}
		return false;		
	}

	public boolean updateHotel(String hotelName) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		Hotel hotel= new Hotel();
	
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			String jpql = "update Hotel m set m.hotelName =:hotelName, m.hotelAddress=:hotelAddress, m.noOfRooms=:noOfRooms, m.contactNumber=:contactNumber where m.hotelName=:hotelName";
			
			Query query = manager.createQuery(jpql);
	
			query.setParameter("hotelName", hotel.getHotelName());
			query.setParameter("hotelAaddress", hotel.getHotelAddress());
			query.setParameter("noOfRoooms", hotel.getNoOfRooms());
			query.setParameter("contactNumber", hotel.getContactNumber() );
						int result = query.executeUpdate();
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
		manager.close();
	
	}
		return false;
		
	}

	public Hotel getHotel(String hotelName) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addRoom(Room room) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			//factory = Persistence.createEntityManagerFactory("hibernatedb");
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();	
			manager.persist(room);
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
			return false;
		} finally {
		manager.close();
	//	factory.close();
		}
	}

	public boolean deleteRoom(String roomNumber) {
		EntityManager manager = null;
		EntityTransaction transaction = null;
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			Room removeRoom =manager.find(Room.class, Integer.parseInt(roomNumber));
			manager.remove(removeRoom);

			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
		manager.close();
			}
		return false;
	}

	public boolean updateRoom(int roomNumber) {
		EntityManagerFactory factory = null;
		EntityManager manager = null;
		EntityTransaction transaction = null;
		Room room = new Room();

		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			String jpql = "update room_info m set m.room number =:mroom number, m.room type=:mroom type, m.room price=:mroom price, where m.room number=:room number";
			// BooksInformation record = manager.find(BooksInformation.class, bookId);
			//TypedQuery<BooksInformation>  query = manager.createQuery(jpql, BooksInformation.class);
			Query query = manager.createQuery(jpql);
			query.setParameter("mroom number", room.getRoomNumber());
			query.setParameter("mroom type", room.getRoomType());
			query.setParameter("mroomPrice", room.getRoomPrice());
			
			int result = query.executeUpdate();
			transaction.commit();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			transaction.rollback();
		} finally {
		manager.close();
	//	factory.close();
	}
		return false;
	}

	public List<Booking> getBookingListRequest() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean updateHotelDetails(String hotelName1, Hotel hotel) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean updateRoomDetails(int roomNumber, Room room) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<Hotel> getHotelList() {
		EntityManagerFactory factory =null;
		EntityManager manager = null;
//		try (FileInputStream fileInputStream = new FileInputStream("databaseproperties.properties")) {
//			Properties properties = new Properties();
//			properties.load(fileInputStream);
	//	factory = Persistence.createEntityManagerFactory("hibernatedb");
		try {
		manager = factory.createEntityManager();
		String jpql = "select m from hotel_info m";
		TypedQuery<Hotel> query = manager.createQuery(jpql, Hotel.class);
		List<Hotel> recordlist = query.getResultList();
		return recordlist;
	} catch(Exception e) {
		e.getMessage();
	} finally {
		manager.close();
	//	factory.close();
	}
		return null;	}
}