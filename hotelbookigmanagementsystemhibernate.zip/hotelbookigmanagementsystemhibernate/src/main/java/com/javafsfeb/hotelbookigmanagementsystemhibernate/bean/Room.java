package com.javafsfeb.hotelbookigmanagementsystemhibernate.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * This class contains Room Information
 *
 */
@Entity
@Table(name="room_info")
public class Room implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Room() {

	}
@Id
@Column(name="roomnumber")
	private int roomNumber;
@Column(name="roomtype")
	private String roomType;
@Column(name="roomprice")
	private double roomPrice;

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public double getRoomPrice() {
		return roomPrice;
	}

	public void setRoomPrice(double roomPrice) {
		this.roomPrice = roomPrice;
	}

	@Override
	public String toString() {
		return "Room [roomNumber=" + roomNumber + ", roomType=" + roomType + ", roomPrice=" + roomPrice + "]";
	}

}
