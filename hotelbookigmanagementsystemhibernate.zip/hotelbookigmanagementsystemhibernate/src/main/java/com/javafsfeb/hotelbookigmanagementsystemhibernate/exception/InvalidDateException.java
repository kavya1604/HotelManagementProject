package com.javafsfeb.hotelbookigmanagementsystemhibernate.exception;

public class InvalidDateException extends Exception {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public InvalidDateException() {

	}
}
