package com.javafsfeb.hotelbookigmanagementsystemhibernate.bean;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="booking_info")
public class Booking implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

		public Booking() {

	}
@Id
@Column(name="fromdate")
	private LocalDate fromDate;
@Column(name="todate")
	private LocalDate toDate;
@Column
	private String name;
@Column(name="hotelname")
	private String hotelName;
@Column
	private String address;
@Column
	private String email;
@Column(name="contact number")
	private long contactNumber;
@Column(name="room number")
	private int roomNum;

	public String getHotelName() {
		return hotelName;
	}

	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}

	public LocalDate getFromDate() {
		return fromDate;
	}

	public void setFromDate(LocalDate fromDate) {
		this.fromDate = fromDate;
	}

	public LocalDate getToDate() {
		return toDate;
	}

	public void setToDate(LocalDate toDate) {
		this.toDate = toDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getRoomNum() {
		return roomNum;
	}

	public void setRoomNum(int roomNum) {
		this.roomNum = roomNum;
	}

	@Override
	public String toString() {
		return "fromDate=" + fromDate + "\n toDate=" + toDate + "\n name=" + name + "\n address=" + address
				+ "\n email=" + email + "\n contactNumber=" + contactNumber + "\n roomNum=" + roomNum
				+ "\n=======================\n";
	}

}
