package com.javafsfeb.hotelbookigmanagementsystemhibernate.exception;

public class HMSException extends RuntimeException{
	
	private static final long serialVersionUID = 1L;

	public HMSException(String msg) {
		super(msg);
	}
}
