package com.capgemini.hotelapp.service;

public interface AdminService {
public boolean adminService();
}
