package com.capgemini.hotelapp.service;

import org.apache.log4j.Logger;

import com.capgemini.hotelapp.bean.CustomerRegistration;
import com.capgemini.hotelapp.dao.CustomerRegistrationDao;
import com.capgemini.hotelapp.factory.Factory;

public  class RegistrationServiceImpl implements RegistrationService{
	
	static Logger log=Logger.getLogger(RegistrationServiceImpl.class);
CustomerRegistrationDao customer=Factory.getRegistrationDAOInstance();
CustomerRegistration customerregister=Factory.getCustomerRegistration();
public boolean registerService() {
	 customer.register(customerregister );

	 return true;
}
CustomerRegistrationDao customerlogin=Factory.getRegistrationDAOInstance();
}