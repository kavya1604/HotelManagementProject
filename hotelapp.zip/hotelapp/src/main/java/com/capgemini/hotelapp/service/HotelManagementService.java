package com.capgemini.hotelapp.service;

public interface HotelManagementService {
public boolean hotelManagementService();
}
