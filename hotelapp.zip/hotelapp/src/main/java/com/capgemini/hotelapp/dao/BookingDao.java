package com.capgemini.hotelapp.dao;

import java.time.LocalDate;

import java.util.List;

import com.capgemini.hotelapp.bean.Booking;


public interface BookingDao {
	
	

	public List<Booking> getBookingDetailsForSpecificHotel(String hotelName);
	


	public Booking getBookingDetailsForSpecificDate(LocalDate bookingDate);

	public List<Booking> getBookingDetails();

	public boolean addBooking(Booking booking);
	public boolean BookingHotel();
}
