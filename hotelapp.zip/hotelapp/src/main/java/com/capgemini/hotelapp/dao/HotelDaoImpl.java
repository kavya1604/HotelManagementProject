
package com.capgemini.hotelapp.dao;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;


import org.apache.log4j.Logger;


import com.capgemini.hotelapp.bean.Hotel;
import com.capgemini.hotelapp.exception.HotelNameNotFoundException;
import com.capgemini.hotelapp.factory.Factory;

public class HotelDaoImpl implements HotelDao{
	static final Logger log = Logger.getLogger(HotelDaoImpl.class);
	static List<Hotel> hotelList = new ArrayList<Hotel>();
	Scanner scanner = new Scanner(System.in);
	static {

		Hotel hotel = Factory.getHotelInstance();

		hotel.setHotelName("Taj Hotel");
		hotel.setHotelAddress("Mumbai, Maharashtra");
		hotel.setNoOfRooms(20);
		hotel.setContactNumber(9028802697l);

		Hotel hotel1 = Factory.getHotelInstance();

		hotel1.setHotelName("Athithi grand hotel");
		hotel1.setHotelAddress("hyderabad,telangana");
		hotel1.setNoOfRooms(25);
		hotel1.setContactNumber(9976645567l);


		hotelList.add(hotel);
		hotelList.add(hotel1);

	}

	public boolean addHotel() {

		Hotel hotel = Factory.getHotelInstance();

		log.info(" Please enter hotel name");
		String hotelName = scanner.nextLine();
		while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
			log.info("Please enter valid hotel name ");
			hotelName = scanner.nextLine();
		}

		log.info("Please enter hotel address");
		String hotelAddress = scanner.nextLine();
		while (!Factory.getInputValidationInstance().hotelAddressValidation(hotelAddress)) {
			log.info("Please enter valid hotel address  ");
			hotelAddress = scanner.nextLine();
		}

		log.info("Please enter contact number(start with 7,8,9)");
		String contactNumber = scanner.nextLine();
		while (!Factory.getInputValidationInstance().hotelContactNumberValidation(contactNumber)) {
			log.info("\n Please enter valid contact number ");
			contactNumber = scanner.nextLine();
		}
		long hotelContactNumber = Long.parseLong(contactNumber);

		log.info("Please enter total number rooms in hotel(2 digits)");
		String noOfRooms = scanner.next();
		while (!Factory.getInputValidationInstance().ageValidation(noOfRooms)) {
			log.info("please enter valid number of rooms");
			noOfRooms = scanner.next();
		}
		int numberOfRooms = Integer.parseInt(noOfRooms);
		hotel.setHotelName(hotelName);
		hotel.setHotelAddress(hotelAddress);
		hotel.setNoOfRooms(numberOfRooms);
		hotel.setContactNumber(hotelContactNumber);

		ArrayList<Hotel> hotelList1 = new ArrayList<Hotel>();
		hotelList1.add(hotel);
		hotelList.addAll(hotelList1);
		if (hotelList1.isEmpty()) {
			log.error("hotel details are not added");
		} else {
			log.info("New  hotel details are added ");
		}
		return false;

	}

	public boolean deleteHotel(String hotelName) {
		int count=0;
		Iterator<Hotel> hotel = hotelList.iterator();
		while (hotel.hasNext()) {
			Hotel str = hotel.next();
			if (str.getHotelName().equals(hotelName)) {
			count++;
				hotel.remove();
				log.info("Data deleted successfully");
			}
	
		}
		try {
			if(count==0) {
				throw new HotelNameNotFoundException();
			}
		}catch(HotelNameNotFoundException e) {
			log.info(" hotel name not found ");
		}
		return false;
	}

	public  boolean updateHotel(Hotel hotel) {
	
		log.info("enter Hotel Name");

		String hotelName1 = scanner.nextLine();
		while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName1)) {
			log.info("please enter valid id");
			hotelName1 = scanner.nextLine();
		}
		int count = 0;
				for (Hotel hotel1 : hotelList) {
			
			

			if (hotel1.getHotelName().equals(hotelName1) ) {
				count++;
					log.info("Request is Done ");
				log.info(" ============= update details ==============");


				log.info("update hotel  name");
				String hotelName2 = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName2)) {
					log.info("please enter valid name");
					hotelName2 = scanner.nextLine();
				}
			hotel1.setHotelName(hotelName2);

				log.info("update hotel address");
				String hotelAdress = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelAddressValidation(hotelAdress)) {
					log.info("please enter valid address");
					hotelAdress = scanner.nextLine();
				}
				
				hotel1.setHotelAddress(hotelAdress);

				log.info("update number of rooms(2 digits)");
				String numOfRooms = scanner.nextLine();
				while (!Factory.getInputValidationInstance().numberOfRoomsValidation(numOfRooms)) {
					log.info("please enter valid number of rooms");
					numOfRooms = scanner.nextLine();
				}
				
				
				int numberOfRooms = Integer.parseInt(numOfRooms);
				hotel1.setNoOfRooms(numberOfRooms);

				log.info("update contact number(start with 7,8,9)");
				String phno = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelContactNumberValidation(phno)) {
					log.info("please enter valid contact number");
					phno= scanner.nextLine();
				}
			long phno1=Long.parseLong(phno);
				hotel1.setContactNumber(phno1);
			}

			}
				try {
				if(count == 0) {
					throw new HotelNameNotFoundException();
					
				}else {
				log.info("Hotel Details Updated Sucessfully");

				}
				}catch(HotelNameNotFoundException e) {
				log.info("Hotel Name Not Found");	
				}
				return false;
       
		
		
	}

			public List<Hotel> getAllHotelDetails() {
		int count=1;
		for (Hotel hotel : hotelList) {
			
			log.info(count+ "." + hotel.getHotelName());
			count++;
			
		}
		return hotelList;
	}
	
}
			
			
		
	


