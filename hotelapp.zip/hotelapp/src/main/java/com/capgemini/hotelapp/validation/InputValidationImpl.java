package com.capgemini.hotelapp.validation;

import java.util.regex.Matcher;

import java.util.regex.Pattern;

public class InputValidationImpl implements InputValidation{
	Pattern pat = null;
	Matcher mat = null;
	public boolean nameValidation(String name) {
		pat=Pattern.compile("\\w+\\s\\w+");
		mat=pat.matcher(name);
		if(mat.matches()) {
			return true; 
		}
				return false;
	}
	public boolean emailValidation(String email) {
		pat=Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
		mat=pat.matcher(email);
		if(mat.matches()) {
        return true;
}
		
		return false;
	}
	public boolean phnoValidation(String phno) {
		pat=Pattern.compile("(0/91)?[7-9][0-9]{9}" );
		mat=pat.matcher(phno);
		if(mat.matches()) {
			return true;
		
		}
		
		return false;
	}
	public boolean choiceValidate(String choice) {
		pat=Pattern.compile("[1-5]");
		mat=pat.matcher(choice);
		if(mat.matches()) {
			return true;
		}		return false;
	}
	public boolean usernameValidation(String username) {
		pat=Pattern.compile("^[a-z0-9_-]{3,15}$");
		mat=pat.matcher(username);
		if(mat.matches()) {
			return true;
		}
				return false;
	}
	public boolean passwordValidation(String password) {
		pat=Pattern.compile("((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%]).{6,20})");
		mat=pat.matcher(password);
		if(mat.matches()) {
			return true;

		}
		return false;
	}
	public boolean ageValidation(String age) {
		pat=Pattern.compile("\\d{2}");
		mat=pat.matcher(age);
		if(mat.matches()) {
			return true;
		}
			return false;
	}
	
	public boolean choiceValidateAdminOperation(String choice) {
		pat = Pattern.compile("[1-7]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean choiceValidateBookingForSpecificHotel(String choice) {
		pat = Pattern.compile("[1-2]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean choiceValidateGuestListForSpecificHotel(String choice) {
		pat = Pattern.compile("[1-2]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean bookingDateValidation(String bookingDate) {
		if (bookingDate.matches("^(\\d{4})-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])$")) {
			return true;
		}
		return false;
	}

	public boolean hotelNameValidation(String hotelName) {
		pat = Pattern.compile("[a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+[a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]");
		mat = pat.matcher(hotelName);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean hotelAddressValidation(String hotelAddress) {
		pat = Pattern.compile("[a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]+[a-zA-Z]+|[a-zA-Z]+\\s[a-zA-Z]");
		mat = pat.matcher(hotelAddress);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean hotelContactNumberValidation(String contactNumber) {
		if (contactNumber.matches("(0/91)?[7-9][0-9]{9}")) {
			return true;
		}
		return false;
	}

	public boolean choiceValidateOperateHotelDetails(String choice) {
		pat = Pattern.compile("[1-4]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	

	public boolean choiceValidateOperateRoomDetails(String choice) {
		pat = Pattern.compile("[1-5]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}
	public boolean choiceValidateCustomerOperations(String choice) {
		pat = Pattern.compile("[1-2]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}
		public boolean choiceValidateEmployeeOperations(String choice) {
		pat = Pattern.compile("[1-4]");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

		@Override
	public boolean roomNumberValidation(String roomNum) {
		pat=Pattern.compile("\\d{3}");
		mat=pat.matcher(roomNum);
		if(mat.matches()) {
			return true;
		}
			return false;
	}
public boolean roomTypeValidation(String roomType) {
	pat=Pattern.compile("[a-z]*");
	mat=pat.matcher(roomType);
	if(mat.matches()) {
		return true;
	}
		return false;

}
@Override
public boolean numberOfRoomsValidation(String noOfRooms) {
	pat=Pattern.compile("\\d{2,3}");
	mat=pat.matcher(noOfRooms);
	if(mat.matches()) {
		return true;
	}
		return false;

		
}
public boolean bookingNameValidation(String name) {
	pat=Pattern.compile("\\w+");
	mat=pat.matcher(name);
	if(mat.matches()) {
		return true; 
	}
	return false;
}
public boolean choiceUpdateCustomerDetailsValidate(String choice) {
	pat = Pattern.compile("[1-4]");
	mat = pat.matcher(choice);
	if (mat.matches()) {
		return true;
	}

	return false;
}
	}



