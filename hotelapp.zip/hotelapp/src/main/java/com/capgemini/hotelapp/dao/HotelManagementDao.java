package com.capgemini.hotelapp.dao;

public interface HotelManagementDao {

	public boolean getEmployeeLogin();
	
	public boolean employeeOperations();
	

		
		
	}
	
