package com.capgemini.hotelapp.dao;

import com.capgemini.hotelapp.bean.Room;

public interface RoomDao {

	public boolean addRoom();

	public boolean deleteRoom(String roomNumber);

	public boolean updateRoom(Room room1);
}
