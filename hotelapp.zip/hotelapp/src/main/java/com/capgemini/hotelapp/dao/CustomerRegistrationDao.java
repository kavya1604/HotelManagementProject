package com.capgemini.hotelapp.dao;

import java.util.List;

import com.capgemini.hotelapp.bean.CustomerRegistration;

public interface CustomerRegistrationDao {

	public boolean register(CustomerRegistration customerRegistration);
	public List<CustomerRegistration> getAllCustomers();
	
	}
