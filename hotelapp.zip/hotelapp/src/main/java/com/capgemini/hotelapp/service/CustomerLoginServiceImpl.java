package com.capgemini.hotelapp.service;

import com.capgemini.hotelapp.controller.HotelController;

import com.capgemini.hotelapp.dao.CustomerLoginDao;
import com.capgemini.hotelapp.factory.Factory;
import org.apache.log4j.*;
public class CustomerLoginServiceImpl implements CustomerLoginService{
static final Logger log=Logger.getLogger(HotelController.class);
CustomerLoginDao customerlogindao=Factory.getLoginDaoInstance();
public boolean customerLginService() {
	customerlogindao.login();
	return true;
	
}
}
