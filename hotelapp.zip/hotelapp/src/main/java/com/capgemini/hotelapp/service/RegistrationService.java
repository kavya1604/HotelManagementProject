package com.capgemini.hotelapp.service;

public interface RegistrationService {
public boolean registerService();
}
