package com.capgemini.hotelapp.service;

import com.capgemini.hotelapp.dao.HotelManagementDao;
import com.capgemini.hotelapp.factory.Factory;

public class HotelManagementServiceImpl implements HotelManagementService{

	public boolean hotelManagementService() {
		HotelManagementDao hotelManagement=Factory.getHotelManagementDaoImpl();
		hotelManagement.getEmployeeLogin();
		return false;
	}
	

}
