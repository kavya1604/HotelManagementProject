package com.capgemini.hotelapp.exception;

@SuppressWarnings("serial")
public class InvalidDateException extends Exception{
public InvalidDateException() {
	
}
}
