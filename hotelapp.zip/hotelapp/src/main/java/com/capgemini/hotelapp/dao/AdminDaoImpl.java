package com.capgemini.hotelapp.dao;

import java.time.LocalDate;


import java.util.Scanner;

import org.apache.log4j.Logger;


import com.capgemini.hotelapp.bean.Hotel;
import com.capgemini.hotelapp.bean.Room;
import com.capgemini.hotelapp.factory.Factory;

public class AdminDaoImpl implements AdminDao{

	static final Logger log = Logger.getLogger(AdminDaoImpl.class);
	Scanner scanner = new Scanner(System.in);

	public void listOfHotels() {

		Factory.getHotelDaoImplInstance().getAllHotelDetails();
	}

	public void bookingForSpecificHotel() {

		
		log.info("Booking For Specific Hotel");

	P:	do {
			log.info("Please select, which hotel booking details you required");
			listOfHotels();
			log.info("Please enter hotel name");
			String hotelName = scanner.nextLine();
			while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
				log.error("Please enter valid hotel name");
				hotelName = scanner.nextLine();
			}
			
			Factory.getBookingDaoImplInstance().getBookingDetailsForSpecificHotel(hotelName);
		
			break P;
		} while (true);
	}
	

	

	public void bookingForSpecificDate() {

	P:	do {
			log.info("Please enter date(Format:YYYY/MM/DD)");
			String date = scanner.nextLine();
			while (!Factory.getInputValidationInstance().bookingDateValidation(date)) {
				log.info("Please enter valid date");
				date = scanner.nextLine();
			}

			LocalDate bookingDate = LocalDate.parse(date);
			Factory.getBookingDaoImplInstance().getBookingDetailsForSpecificDate(bookingDate);

			break P;
		} while (true);

	}

	public void operateHotelDetails() {

		L: do {
			
			log.info("1. Add Hotel ");
			log.info("2. Delete Hotel");
			log.info("3. Update Hotel");
			log.info("4. Exit ");
             String choice = scanner.nextLine();
			while (!Factory.getInputValidationInstance().choiceValidateOperateHotelDetails(choice)) {
				log.error("Please enter valid choice");
				choice = scanner.next();
			}

			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				Factory.getHotelDaoImplInstance().addHotel();
				break;

			case 2:
				log.info("Please enter hotel name");
				String hotelName = scanner.nextLine();
				while (!Factory.getInputValidationInstance().hotelNameValidation(hotelName)) {
					log.info("Please enter valid hotel name");
					hotelName = scanner.nextLine();
				}
				Factory.getHotelDaoImplInstance().deleteHotel(hotelName);
				break;

			case 3:
				Hotel hotel1= Factory.getHotelInstance();
				HotelDao hoteldao = Factory.getHotelDaoImplInstance();
				hoteldao.updateHotel(hotel1);				
				break;
			
			case 4:
				
				break L;

			default:
				log.error("Please enter valid input");
				break;
			}
		} while (true);
	}
	
	
	public void operateRoomDetails() {
		
	P:	do {
			log.info("1. Add Room");
			log.info("2. Delete Room");
			log.info("3. Update Room ");
				log.info(" 4. Exit ");

			String choice = scanner.nextLine();
			while (!Factory.getInputValidationInstance().choiceValidateOperateRoomDetails(choice)) {
				log.error("Please enter valid choice ");
				choice = scanner.next();
			}

			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:
				Factory.getRoomDaoImplInstance().addRoom();
				break;

			case 2:
				log.info("Please enter room number ");
				String roomNumber = scanner.nextLine();
				while (!Factory.getInputValidationInstance().roomNumberValidation(roomNumber)) {
					log.info("please enter valid room number");
					roomNumber = scanner.next();
				}
				
				Factory.getRoomDaoImplInstance().deleteRoom(roomNumber);
				break;

			case 3:
				
				Room room1= Factory.getRoomInstance();
				RoomDao roomdao = Factory.getRoomDaoImplInstance();
				roomdao.updateRoom(room1);				
				break;
				
				case 4:
			
				break P;

			default:
				log.error("Please enter valid input");
				break;
			}
		} while (true);
	}

	

}
