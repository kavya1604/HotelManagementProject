package com.capgemini.hotelapp.factory;

import com.capgemini.hotelapp.validation.InputValidation;
import com.capgemini.hotelapp.validation.InputValidationImpl;
import com.capgemini.hotelapp.bean.AdminLogin;
import com.capgemini.hotelapp.bean.Booking;
import com.capgemini.hotelapp.bean.CustomerRegistration;
import com.capgemini.hotelapp.bean.Hotel;
import com.capgemini.hotelapp.bean.HotelManagementLogin;
import com.capgemini.hotelapp.bean.Room;
import com.capgemini.hotelapp.controller.HotelController;
import com.capgemini.hotelapp.dao.BookingDaoImpl;
import com.capgemini.hotelapp.dao.AdminDaoImpl;
import com.capgemini.hotelapp.dao.AdminLoginDaoImpl;
import com.capgemini.hotelapp.dao.CustomerLoginDao;
import com.capgemini.hotelapp.dao.CustomerLoginDaoImpl;
import com.capgemini.hotelapp.dao.CustomerRegistrationDao;
import com.capgemini.hotelapp.dao.CustomerRegistrationDaoImpl;
import com.capgemini.hotelapp.dao.HotelDaoImpl;
import com.capgemini.hotelapp.dao.HotelManagementDaoImpl;

import com.capgemini.hotelapp.dao.RoomDaoImpl;
import com.capgemini.hotelapp.service.AdminService;
import com.capgemini.hotelapp.service.AdminServiceImpl;
import com.capgemini.hotelapp.service.CustomerLoginService;
import com.capgemini.hotelapp.service.CustomerLoginServiceImpl;
import com.capgemini.hotelapp.service.HotelManagementService;
import com.capgemini.hotelapp.service.HotelManagementServiceImpl;
import com.capgemini.hotelapp.service.RegistrationService;
import com.capgemini.hotelapp.service.RegistrationServiceImpl;

public abstract class Factory {

public static CustomerRegistration getCustomerRegistration(){
		CustomerRegistration customerRegisteration = new CustomerRegistration();
		return customerRegisteration;
		
}
public static CustomerRegistrationDao getRegistrationDAOInstance() {
	CustomerRegistrationDao registerDao = new CustomerRegistrationDaoImpl();
	return registerDao;
}


	
	public static InputValidation getInputValidationInstance() {

		return new InputValidationImpl();
	}
	public static CustomerLoginDao getLoginDaoInstance() {
		CustomerLoginDao loginDao=new CustomerLoginDaoImpl();
		return loginDao;
	}
	public static AdminLoginDaoImpl getLoginDaoImplInstance() {
	
		return new AdminLoginDaoImpl();
	}
	

	public static AdminDaoImpl getAdminDaoImplInstance() {
		return new AdminDaoImpl();
	}	

	public static Booking getBookingInstance() {
		return new Booking();
	}

	public static BookingDaoImpl getBookingDaoImplInstance() {
		return new BookingDaoImpl();
	}

	
	public static AdminLogin getAdminInstance() {
		return new AdminLogin();
	}

	public static Hotel getHotelInstance() {
		return new Hotel();
	}

	public static HotelDaoImpl getHotelDaoImplInstance() {
		return new HotelDaoImpl();
	}

	public static Room getRoomInstance() {
		return new Room();
	}

	public static RoomDaoImpl getRoomDaoImplInstance() {
		return new RoomDaoImpl();
	}
	public static HotelController getHotelControllerInstance() {
		return new HotelController();
	}
	public static HotelManagementLogin getHotelManagementLoginInstance() {
		return new HotelManagementLogin();
	}
	public static HotelManagementDaoImpl getHotelManagementDaoImpl() {
		return new HotelManagementDaoImpl();
		
		}
	public static HotelManagementService getHotelManagementServiceImplInstance() {
		return new HotelManagementServiceImpl();
	}

	public static AdminService getAdminServiceImplInstance() {
		return new AdminServiceImpl();
	}

	public static RegistrationService getRegistrationServiceImplInstance() {
		return new RegistrationServiceImpl();
	}

	public static CustomerLoginService getCustomerLoginServiceImplInstance() {
		return new CustomerLoginServiceImpl();
	}
	
	}



