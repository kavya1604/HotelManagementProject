package com.capgemini.hotelapp.exception;

@SuppressWarnings("serial")
public class HotelNameNotFoundException extends Exception{
	public HotelNameNotFoundException() {

	}
}
