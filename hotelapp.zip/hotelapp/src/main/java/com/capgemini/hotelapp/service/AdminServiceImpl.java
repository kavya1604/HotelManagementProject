package com.capgemini.hotelapp.service;

import com.capgemini.hotelapp.dao.AdminLoginDao;
import com.capgemini.hotelapp.factory.Factory;

public class AdminServiceImpl implements AdminService{

	
	public boolean adminService() {
		AdminLoginDao adminDao=Factory.getLoginDaoImplInstance();
		adminDao.adminLogin();
		return false;
	}

}
