package com.capgemini.hotelapp.service;

public interface CustomerLoginService {
public boolean customerLginService();
}
