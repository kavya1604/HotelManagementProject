package com.capgemini.hotelapp.dao;

import java.io.FileInputStream;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelapp.bean.AdminLogin;
import com.capgemini.hotelapp.factory.Factory;

public class AdminLoginDaoImpl implements AdminLoginDao {

	static final Logger log = Logger.getLogger(AdminLoginDaoImpl.class);

	static List<AdminLogin> adminlist = new ArrayList<AdminLogin>();
	Scanner scanner = new Scanner(System.in);

	public void adminLogin() {
		AdminLogin admin = Factory.getAdminInstance();

		Properties properties = new Properties();

		try {
			properties.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		admin.setUsername("admin");
		admin.setPassword("admin");

		adminlist.add(admin);

		// log.info("Username : ");
		String username = properties.getProperty("adminUsername");
		// log.info("Password : ");
		String password = properties.getProperty("adminPassword");

		int count = 0;
		for (AdminLogin admin1 : adminlist) {
			if (admin1.getUsername().equals(username) && admin1.getPassword().equals(password)) {
				count++;
			}
			if (count == 1) {
				log.info("Login Successfully");
				loginAdminOperations();
			} else {
				log.info("Login failed");
			}
		}
	}

	public void loginAdminOperations() {
		do {
			log.info(" 1. View List of Hotels");
			log.info(" 2. View Bookings of Specific Hotel");
			log.info(" 3. View Booking for Specific Date");
			log.info(" 4. Operate Hotel Details");
			log.info(" 5. Operate Room Details");
			log.info(" 6. Logout\n");

			String choice = scanner.next();
			while (!Factory.getInputValidationInstance().choiceValidateAdminOperation(choice)) {
				log.error("Please enter valid choice");
				choice = scanner.next();
			}

			int choice1 = Integer.parseInt(choice);
			switch (choice1) {

			case 1:

				Factory.getAdminDaoImplInstance().listOfHotels();
				break;

			case 2:
				Factory.getAdminDaoImplInstance().bookingForSpecificHotel();
				break;

			case 3:
				Factory.getAdminDaoImplInstance().bookingForSpecificDate();
				break;

			case 4:
				Factory.getAdminDaoImplInstance().operateHotelDetails();
				break;
			case 5:
				Factory.getAdminDaoImplInstance().operateRoomDetails();
				break;
			case 6:
				Factory.getHotelControllerInstance().hotelManagementSystem();
				break;
			}
		} while (true);
	}

}