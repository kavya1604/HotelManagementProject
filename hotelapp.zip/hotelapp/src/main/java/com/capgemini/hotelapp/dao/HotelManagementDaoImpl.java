package com.capgemini.hotelapp.dao;

import java.util.ArrayList;


import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.hotelapp.bean.HotelManagementLogin;
import com.capgemini.hotelapp.controller.HotelController;
import com.capgemini.hotelapp.factory.Factory;
import com.capgemini.hotelapp.validation.InputValidation;

public class HotelManagementDaoImpl implements HotelManagementDao{
	static List<HotelManagementLogin> managementList = new ArrayList<HotelManagementLogin>();

	static final Logger log= Logger.getLogger(HotelController.class);
	InputValidation inputvalidation = Factory.getInputValidationInstance();
	Scanner sc = new Scanner(System.in);
	
	

	
	public boolean getEmployeeLogin() {
String username;
String password;

HotelManagementLogin login1=Factory.getHotelManagementLoginInstance();
login1.setUsername("saikumar12");
login1.setPassword("Saikumar@12");
HotelManagementLogin login2=Factory.getHotelManagementLoginInstance();
login2.setUsername("manikanta20");
login2.setPassword("manikanta@20");
managementList.add(login1);
managementList.add(login2);


log.info("Please enter your login details");
log.info("Username : ");
username = sc.nextLine();
log.info("Password : ");
password = sc.nextLine();
int count=0;
for (HotelManagementLogin managementLogin : managementList) {
	if (managementLogin.getUsername().equals(username) && managementLogin.getPassword().equals(password)) {
		count++;
	}
}
if(count==1) {
		log.info("Login Success");
		employeeOperations();
}else {
		log.info("Login failed\n");
	}


return false;

}
					@Override
	public boolean employeeOperations() {
		 do {
				
				log.info("1.View Customer List");
				log.info("2.View Booking List");
				log.info("3.hotel Booking");
				log.info("4.Exit");
				String choice = sc.nextLine();
				while (!Factory.getInputValidationInstance().choiceValidateEmployeeOperations(choice)) {
					log.error("Please enter valid choice");
					choice = sc.next();
				}

             int choice1 = Integer.parseInt(choice);

			switch (choice1) {

				
			case 1:
					CustomerRegistrationDao customerregistrationdao=Factory.getRegistrationDAOInstance();
					customerregistrationdao.getAllCustomers();
					break;
				case 2:
					BookingDao bookingdao=Factory.getBookingDaoImplInstance();
					bookingdao.getBookingDetails();
					break;
				case 3:
					Factory.getBookingDaoImplInstance().BookingHotel();
				case 4:
					Factory.getHotelControllerInstance().hotelManagementSystem();
				

				break ;
				default :
					log.info("Enter Valid choice");
					break;
				}
				
			} while(true);

			
			
	}
			


			
		}
		
		

	