package com.capgemini.hotelapp.dao;

public interface AdminLoginDao {

	public void adminLogin();
}
