package com.capgemini.hotelapp.exception;

@SuppressWarnings("serial")
public class RoomNumberNotFoundException extends Exception{

public RoomNumberNotFoundException() {
	
}
}
