package com.capgemini.hotelapp.dao;

import java.util.ArrayList;



import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;


import com.capgemini.hotelapp.bean.CustomerRegistration;

import com.capgemini.hotelapp.factory.Factory;
import com.capgemini.hotelapp.validation.InputValidation;

public class CustomerRegistrationDaoImpl implements CustomerRegistrationDao {
	static final Logger log = Logger.getLogger(CustomerRegistrationDaoImpl.class);
	int count = 0;
	InputValidation inputValidations = null;
	static List<CustomerRegistration> customer = new ArrayList<CustomerRegistration>();
	static int size;
	Scanner sc1 = new Scanner(System.in);

	static {

		CustomerRegistration customer1 = Factory.getCustomerRegistration();
		customer1.setName("kavya nalabolu");
		customer1.setUsername("kavya16");
		customer1.setPassword("Kavya@16");
		customer1.setPhno(9876543210l);
		customer1.setMailId("kavya16@gmail.com");
		customer1.setAge(23);

		CustomerRegistration customer2 = Factory.getCustomerRegistration();
		customer2.setName("keerthi reddy");
		customer2.setUsername("keerthi27");
		customer2.setPassword("keerthi27K@");
		customer2.setPhno(7965556545l);
		customer2.setMailId("keerthi27@gmail.com");
		customer2.setAge(26);

		CustomerRegistration customer3 = Factory.getCustomerRegistration();
		customer3.setName("sahithi reddy");
		customer3.setUsername("sahithi sahithi14");
		customer3.setPassword("sahithi14S$");
		customer3.setPhno(9856425457l);
		customer3.setMailId("sahithi14@gmail.com");
		customer3.setAge(24);

		customer.add(customer1);
		customer.add(customer2);
		customer.add(customer3);
		size = customer.size();

	}

	public boolean register(CustomerRegistration customerRegistration) {
		InputValidation inputValidation = Factory.getInputValidationInstance();
		CustomerRegistration cr = Factory.getCustomerRegistration();
		log.info("Enter your name(firstname lastname)");
		String name = sc1.nextLine();
		while (!inputValidation.nameValidation(name)) {
			log.info("please enter valid name(firstname lastname)");
			name = sc1.nextLine();
		}

		
		log.info("Enter username(start with digits or characters,-,_)");
				String username = sc1.nextLine();
		while (!inputValidation.usernameValidation(username)) {
			log.info("please enter valid username(start with digits or characters,-,_)");
			username = sc1.nextLine();
		}

		log.info("Enter password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
		String password = sc1.next();
		while (!inputValidation.passwordValidation(password)) {
			log.info("please enter valid password(must contain uppercase letter,lowercase letter,special characters @#$%,atleast one digit,minimum 6 max 20)");
			password = sc1.next();
		}

		log.info("Enter phno(start with 7,8,9)");
		String phone = sc1.next();
		while (!inputValidation.phnoValidation(phone)) {
			log.info("please enter valid phno(start with 7,8,9)");
			phone = sc1.next();
		}
		long phno = Long.parseLong(phone);

		log.info("Enter mailId(must contain @ .)");
		String mailid = sc1.next();
		while (!inputValidation.emailValidation(mailid)) {
			log.info("please enter valid mailid(must contain @ .)");
			mailid = sc1.next();
		}
		log.info("Enter your age(2 digits)");
		String age1 = sc1.next();
		while (!inputValidation.ageValidation(age1)) {
			log.info("please enter valid age");
			age1= sc1.next();
		}

		
		int age = Integer.parseInt(age1);
		cr.setName(name);
		cr.setUsername(username);
		cr.setPhno(phno);
		cr.setAge(age);
		cr.setMailId(mailid);
		cr.setPassword(password);

		ArrayList<CustomerRegistration> list = new ArrayList<CustomerRegistration>();

		list.add(cr);
		customer.addAll(list);
		if (list.isEmpty()) {
			log.info("Registration unsuccessful\n");
			return false;
		} else {
			log.info("Registration successfull");

			return true;

		}
	}

	@Override
	public List<CustomerRegistration> getAllCustomers() {
		log.info("list of Customers");
		
		for (int i = 0; i < customer.size(); i++) {
			log.info("\n"+ customer.get(i));
		}
		return customer;
	}
		}