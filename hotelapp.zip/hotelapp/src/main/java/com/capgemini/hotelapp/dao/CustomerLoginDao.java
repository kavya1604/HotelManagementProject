package com.capgemini.hotelapp.dao;

public interface CustomerLoginDao {
public boolean login();
public boolean customerOperations();


}
