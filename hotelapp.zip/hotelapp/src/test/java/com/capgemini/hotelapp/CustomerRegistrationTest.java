package com.capgemini.hotelapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Scanner;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelapp.bean.CustomerRegistration;
import com.capgemini.hotelapp.dao.CustomerRegistrationDao;
import com.capgemini.hotelapp.factory.Factory;
import com.capgemini.hotelapp.validation.InputValidation;


public class CustomerRegistrationTest {
	static final Logger log = Logger.getLogger(CustomerRegistrationTest.class);

	Scanner scanner = new Scanner(System.in);
	InputValidation inputValidation = Factory.getInputValidationInstance();
	CustomerRegistration customerRegister = Factory.getCustomerRegistration();

	@Test
	@DisplayName("Customer Account Exist or Not")
	void testcustomerRegistrationTest() {

		log.info("Test Case for Customer Account Exist or Not");

		customerRegister.setName("kavya nalabolu");
		customerRegister.setMailId("kavya16@gmail.com");
		customerRegister.setPhno(9876543210l);
		customerRegister.setUsername("kavya16");
		customerRegister.setPassword("Kavya@16");
		customerRegister.setAge(23);
		log.info("Please enter your details");

		log.info("Please enter your name");
		String name = scanner.nextLine();
		while (!inputValidation.nameValidation(name)) {
			log.error("Please enter valid  name (Name must contain firstname and lastname) ");
			name = scanner.nextLine();
		}
		assertEquals(name, customerRegister.getName());

		log.info("Please enter email");
		String email = scanner.nextLine();
		while (!inputValidation.emailValidation(email)) {
			log.error("Please enter valid  email (Email must contain @ . )");
			email = scanner.nextLine();
		}
		assertEquals(email, customerRegister.getMailId());

		log.info("Please enter contact number");
		String contactNumber = scanner.nextLine();
		while (!inputValidation.phnoValidation(contactNumber)) {
			log.error(
					"\nPlease enter valid contact number (Contact Number must 10 digits and start with 7-9 digit only) ");
			contactNumber = scanner.nextLine();
		}
		Long contactNumber1 = Long.parseLong(contactNumber);
		assertEquals(contactNumber1, customerRegister.getPhno());

		log.info("Please enter username");
		String username = scanner.nextLine();
		while (!inputValidation.usernameValidation(username)) {
			log.error("Please enter valid  username (Username may contain alphabets, number, - , _");
			username = scanner.nextLine();
		}
		assertEquals(username, customerRegister.getUsername());

		log.info("Please enter password");
		String password = scanner.nextLine();
		while (!inputValidation.passwordValidation(password)) {
			log.error("Please enter valid  password (Password must contain atleast one lowercase letter, uppercase letter, digit and special character and legth should be 6-20");
			password = scanner.nextLine();
		}
		assertEquals(password, customerRegister.getPassword());
		
		log.info("Please enter age");
	int age = scanner.nextInt();
				
		assertEquals(age, customerRegister.getAge());

	}

	@Test
	@DisplayName("Add New Customer")
	void testAddCustomer() {
		log.info("Test Case for Add New Customer");
		CustomerRegistrationDao customerRegistrationDao = Factory.getRegistrationDAOInstance();
		assertEquals(true, customerRegistrationDao.register(customerRegister));
	}

	
}

