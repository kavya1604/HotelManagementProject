package com.capgemini.hotelapp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.apache.log4j.Logger;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.capgemini.hotelapp.bean.Hotel;
import com.capgemini.hotelapp.dao.HotelDaoImpl;
import com.capgemini.hotelapp.factory.Factory;

public class HotelOperationsTest {
static Logger log=Logger.getLogger(HotelOperationsTest.class);


     @Test
     @DisplayName("Add Hotel")
     void testAddHotel(){
	HotelDaoImpl hoteloperations=Factory.getHotelDaoImplInstance();
	assertEquals(false,hoteloperations.addHotel());
}
     @Test
     @DisplayName("Delete Hotel")
     void testDeleteHotel(){
    HotelDaoImpl hoteloperations=Factory.getHotelDaoImplInstance();
	assertEquals(false,hoteloperations.deleteHotel("Athithi grand hotel"));
}
     @Test
     @DisplayName("update Hotel")
     void testUpdateHotel(){
    	 
	HotelDaoImpl hoteloperations=Factory.getHotelDaoImplInstance();
	Hotel hotel = Factory.getHotelInstance();
	assertEquals(false,hoteloperations.updateHotel(hotel));
}
}
